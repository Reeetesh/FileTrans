package com.example.weatherapp_starter_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
